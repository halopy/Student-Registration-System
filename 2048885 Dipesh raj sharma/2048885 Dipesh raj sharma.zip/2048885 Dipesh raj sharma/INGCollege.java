
/**
 * Write a description of class INGCollege here.
 *
 * @author (Dipesh raj sharma)
 * @version (a version number or a date)
 * 
 * 
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.*;

public class INGCollege implements ActionListener
{

    private JFrame frame;
    private JPanel panel;
    private JTextField Field,field_coursename,field_duration,field_level,field_credit,field_numofassessments,field_courseid2,field_courseleader,field_lecturer,field_prerequisite;
    private JButton button_addcourse,button_register,button_display,button_clear,button_change,button_remove,button_addnoncourse,button_registern;
    private JComboBox ComboBox_year,ComboBox_month,ComboBox_day,ComboBox_year1,ComboBox_month1,ComboBox_day1,ComboBox_year2,ComboBox_month2,ComboBox_day2;
    private JLabel labeltitle,label_level,label_credit,label_numofassessments,label_lecturername,label_completiondate,label_examdate,label_startdate;
    private Font font1,font2;
    private ArrayList<Course>course = new ArrayList();

    public void gui()
    {
        //JFrame
        frame = new JFrame("Course Registration");
        frame.setBounds(100,100,1000,700);
        frame.setResizable(false);
        //JPanel
        panel=new JPanel();
        Color cc=new Color(255, 118, 117);
        panel.setBackground(cc);
        panel.setLayout(null);

        //panel.setBorder(border);

        //jlabel add course
        labeltitle = new JLabel();
        labeltitle.setText("Academic course");
        labeltitle.setBounds(400,10,400,30);

        //academic course font
        Font fo=new Font("Times new roman",Font.BOLD,25);
        labeltitle.setFont(fo);
        panel.add(labeltitle);

        //jlabel add course
        JLabel label_add= new JLabel("Add course");
        label_add.setBounds(43,70,135,34);
        // add course font
        Font foo =new Font("Times new roman",Font.BOLD,20);
        label_add.setFont(foo);
        panel.add(label_add); 

        //Jbutton font
        font1 = new Font("",Font.BOLD,14);
        //Jbutton font
        font2 = new Font("",Font.BOLD,10);

        //text field font
        Font fa= new Font("arial",Font.PLAIN,15);

        //JLabel for courseid

        JLabel t1=new JLabel("CourseID:");
        t1.setBounds(40,125,100,32);
        t1.setFont(fa);
        panel.add(t1);

        //textfield for courseid
        Field = new JTextField();
        Field.setBounds(220,124,197,26);
        panel.add(Field);

        //jlabel for course name
        JLabel label_coursename=new JLabel("Coursename:");
        label_coursename.setBounds(40,175,110,40);
        label_coursename.setFont(fa);
        panel.add(label_coursename);

        //jtextfield for course name
        field_coursename = new JTextField();
        field_coursename.setBounds(220,180,197,26);
        panel.add(field_coursename);

        //Jlabel for duration
        JLabel label_duration = new JLabel("Duration:");
        label_duration.setBounds(40,225,130,32);
        label_duration.setFont(fa);
        panel.add(label_duration);

        //textfield for duration
        field_duration = new JTextField();
        field_duration.setBounds(220,230,197,26);
        panel.add(field_duration);

        //Jlabel for level
        label_level = new JLabel("Level:");
        label_level.setBounds(40,285,130,32);
        label_level.setFont(fa);
        panel.add(label_level);

        //textfield for level
        field_level = new JTextField();
        field_level.setBounds(220,280,197,26);
        panel.add(field_level);

        //Jlabel for credit
        label_credit = new JLabel("Credit");
        label_credit.setBounds(40,335,130,32);
        label_credit.setFont(fa);
        panel.add(label_credit);

        //textfield for credit
        field_credit = new JTextField();
        field_credit.setBounds(220,330,197,26);
        panel.add(field_credit);

        //Jlabel for assessment
        label_numofassessments = new JLabel("Numofassessments:");
        label_numofassessments.setBounds(40,385,149,40);
        label_numofassessments.setFont(fa);
        panel.add(label_numofassessments);

        //textfield for assessment
        field_numofassessments = new JTextField();
        field_numofassessments.setBounds(220,385,197,26);
        panel.add(field_numofassessments);

        //jbutton for add academic course
        button_addcourse=new JButton("Add Academic Course");
        button_addcourse.setBounds(40,500,270,40);
        button_addcourse.setFont(font1);
        Color ca=new Color(175,238,238);
        button_addcourse.setBackground(ca);
        button_addcourse.addActionListener(this);
        panel.add(button_addcourse);

        //jlabel for register course
        JLabel label_registercourse = new JLabel("Register Course");
        label_registercourse.setBounds(500,70,140,34);
        label_registercourse.setFont(foo);
        panel.add(label_registercourse);

        //JLabel for courseid2

        JLabel label_courseid2=new JLabel("CourseID:");
        label_courseid2.setBounds(500,124,110,40);
        label_courseid2.setFont(fa);
        panel.add(label_courseid2);

        //textfield for courseid
        field_courseid2 = new JTextField();
        field_courseid2.setBounds(680,124,197,24);
        panel.add(field_courseid2);

        //JLabel for courseleader
        JLabel label_courseleader=new JLabel("Course Leader:");
        label_courseleader.setBounds(500,175,110,40);
        label_courseleader.setFont(fa);
        panel.add(label_courseleader);

        //textfield for courseleader
        field_courseleader = new JTextField();
        field_courseleader.setBounds(680,180,197,24);
        panel.add(field_courseleader);

        //JLabel for lecturername
        label_lecturername=new JLabel("lecturer Name:");
        label_lecturername.setBounds(500,225,120,40);
        label_lecturername.setFont(fa);
        panel.add(label_lecturername);

        //textfield for lecturername
        field_lecturer = new JTextField();
        field_lecturer.setBounds(680,230,197,24);
        panel.add(field_lecturer);

        //JLbel for start date
        JLabel label_startdate=new JLabel("Start Date:");
        label_startdate.setBounds(500,285,85,55);
        label_startdate.setFont(fa);
        panel.add(label_startdate);

        Integer year0[]=new Integer[27];
        int a= 1998;
        for(int i = 0 ;i<27;i++)
        {
            year0[i]=a;
            a++;

        }

        //JComboBox for year
        ComboBox_year=new JComboBox(year0);
        ComboBox_year.setBounds(680,295,60,25);
        panel.add(ComboBox_year);

        //JComboBox for months
        String months[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        ComboBox_month = new JComboBox(months);
        ComboBox_month.setBounds(750,295,60,25);
        panel.add(ComboBox_month);

        Integer days[] = new Integer[31];
        for(int i = 0;i<31;i++)
        {

            days[i]= i+1;

        }

        //JComboBox for day
        ComboBox_day=new JComboBox(days);
        ComboBox_day.setBounds(820,295,60,25);
        panel.add(ComboBox_day);

        //jlabel for completiondate
        JLabel label_completiondate=new JLabel("Completion date:");
        label_completiondate.setBounds(500,335,125,55);
        label_completiondate.setFont(fa);
        panel.add(label_completiondate);

        //JComboBox for year
        ComboBox_year1=new JComboBox(year0);
        ComboBox_year1.setBounds(680,345,60,25);
        panel.add(ComboBox_year1);

        //JComboBox for months
        ComboBox_month1 = new JComboBox(months);
        ComboBox_month1.setBounds(750,345,60,25);
        panel.add(ComboBox_month1);

        //JComboBox for day
        ComboBox_day1=new JComboBox(days);
        ComboBox_day1.setBounds(820,345,60,25);
        panel.add(ComboBox_day1);

        //jlabel for examdate
        label_examdate=new JLabel("Exam date:");
        label_examdate.setBounds(500,385,125,55);
        label_examdate.setFont(fa);
        panel.add(label_examdate);
        label_examdate.setVisible(false);

        //JComboBox for year
        ComboBox_year2=new JComboBox(year0);
        ComboBox_year2.setBounds(680,395,60,25);
        panel.add(ComboBox_year2);
        ComboBox_year2.setVisible(false);

        //JComboBox for months
        ComboBox_month2 = new JComboBox(months);
        ComboBox_month2.setBounds(750,395,60,25);
        panel.add(ComboBox_month2);
        ComboBox_month2.setVisible(false);

        //JComboBox for day
        ComboBox_day2=new JComboBox(days);
        ComboBox_day2.setBounds(820,395,60,25);
        panel.add(ComboBox_day2);    
        ComboBox_day2.setVisible(false);

        //register academic course button
        button_register=new JButton("Register academic course");
        button_register.setBounds(470,500,220,40);
        button_register.setFont(font1);
        Color cb = new Color(175,238,238);
        button_register.setBackground(cb);
        button_register.addActionListener(this);
        panel.add(button_register);

        //display button
        button_display=new JButton("Display");
        button_display.setBounds(510,550,150,40);
        button_display.setFont(font1);
        Color cd = new Color(175,238,238);
        button_display.setBackground(cd);
        button_display.addActionListener(this);
        panel.add(button_display);

        //clear button
        button_clear=new JButton("Clear");
        button_clear.setBounds(700,550,150,40);
        button_clear.setFont(font1);
        Color co = new Color(175,238,238);
        button_clear.setBackground(co);
        button_clear.addActionListener(this);
        panel.add(button_clear);

        //change button
        button_change=new JButton("Change to Non Academic Course");
        button_change.setBounds(40,557,270,40);
        button_change.setFont(font1);
        button_change.setBackground(Color.white);
        button_change.addActionListener(this);
        panel.add(button_change);

        //remove button
        button_remove=new JButton("Remove");
        button_remove.setBounds(700,500,150,40);
        button_remove.setFont(font1);
        Color ck = new Color(175,238,238);
        button_remove.setBackground(ck);
        button_remove.addActionListener(this);
        button_remove.setVisible(false);

        panel.add(button_remove);

        //jbutton to add non- academic course
        button_addnoncourse=new JButton("Add Academic Course");
        button_addnoncourse.setBounds(40,500,270,40);
        button_addnoncourse.setFont(font1);
        //Color ca=new Color(175,238,238);
        //button_addnoncourse.setBackground(ca);
        button_addnoncourse.addActionListener(this);
        panel.add(button_addnoncourse);

        //register non academic course button
        button_registern=new JButton("Register Non - academic course");
        button_registern.setBounds(470,500,220,40);
        button_registern.setFont(font1);
        //Color cb = new Color(175,238,238);
        //button_registern.setBackground(cb);
        button_registern.addActionListener(this);
        panel.add(button_registern);
        button_registern.setVisible(false);

        //Jlabel for prerequisite
        JLabel label_prerequisite = new JLabel("prerequisite:");
        label_prerequisite.setBounds(40,285,130,32);
        label_prerequisite.setFont(fa);
        panel.add(label_prerequisite);
        label_prerequisite.setVisible(false);

        //textfield for prerequisite
        field_prerequisite = new JTextField();
        field_prerequisite.setBounds(220,280,197,26);
        panel.add(field_prerequisite);
        field_prerequisite.setVisible(false);

        frame.add(panel);
        frame.setResizable(false);
        frame.setVisible(true); 
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);

    }
    //gettor's method of courseID
    public String getCourseID()
    {
        return this.Field.getText();
    }
    //gettor's method of coursename
    public String getCourseName()
    {
        return this.field_coursename.getText();
    }
    //gettor's method of duration
    public int getduration()
    {
        return Integer.parseInt(this.field_duration.getText());
    }
    // getter method of level
    public String getlevel()
    {
        return this.field_level.getText();
    }
    //getter method of prerequisite
    public String getprerequisite()
    {
        return this.field_prerequisite.getText();
    }
    //getter method of credit
    public String getCredit()
    {
        return this.field_credit.getText();
    }
    //getter method of numofassessment
    public int getNumofAssessments()
    {
        return Integer.parseInt(this.field_numofassessments.getText());
    }
    //gettor method of courseid2
    public String getcourseid2()
    {
        return this.field_courseid2.getText();
    }
    //getter method ofcourse leader
    public String getCourseLeader()
    {
        return this.field_courseleader.getText();
    }
    //getter method of start date
    public String getstartdate()
    {
        String startdate = ComboBox_month.getSelectedItem()+""+ComboBox_day.getSelectedItem()+""+ComboBox_year.getSelectedItem();
        return startdate ;
    }
    //getter method of completion date
    public String getcompletiondate()
    {
        String completiondate = ComboBox_month1.getSelectedItem()+""+ComboBox_day1.getSelectedItem()+""+ComboBox_year1.getSelectedItem();
        return completiondate ;
    }
    //getter method of exam date 
    public String getexamdate()
    {
        String examdate = ComboBox_month2.getSelectedItem()+""+ComboBox_day2.getSelectedItem()+""+ComboBox_year2.getSelectedItem();
        return examdate ;
    }

    // //getter method lecturer name
    public String getLecturerName()
    {
        return this.field_lecturer.getText();
    }

    public void actionPerformed(ActionEvent e)
    {
        String c = e.getActionCommand();
        //change button
        if (c.equals("Change to Non Academic Course"))
        {
            label_level.setText("Prerequisite:");
            button_change.setText("Change to Academic Course");
            label_credit.setVisible(false);
            field_credit.setVisible(false);
            label_numofassessments.setVisible(false);
            field_numofassessments.setVisible(false);
            field_prerequisite.setVisible(true);
            field_level.setVisible(false);
            button_addcourse.setText("Add Non-academic course");
            button_addcourse.setFont(font1);
            button_register.setText("Register Non-academic course");
            button_register.setFont(font1);
            labeltitle.setText("Non-academic course");
            label_lecturername.setText("Instructor Name:");
            label_examdate.setVisible(true);
            ComboBox_year2.setVisible(true);
            ComboBox_month2.setVisible(true);
            ComboBox_day2.setVisible(true);
            button_register.setBounds(470,500,220,40);
            button_remove.setVisible(true);
            button_register.setText("register non academic");
            button_display.setText("Display ");
        }
        else if(c.equals("Change to Academic Course"))
        {
            button_change.setText("Change to Non Academic Course");
            label_level.setText("Level");
            button_change.setVisible(true);
            label_credit.setVisible(true);
            field_credit.setVisible(true);
            label_numofassessments.setVisible(true);
            field_numofassessments.setVisible(true);
            field_prerequisite.setVisible(false);
            field_level.setVisible(true);
            button_addcourse.setText("Add academic course");
            button_addcourse.setFont(font1);
            button_register.setText("Register academic course");
            button_register.setFont(font1);
            labeltitle.setText("Academic course");
            label_lecturername.setText("Lecturer name:");
            label_examdate.setVisible(false);
            ComboBox_year2.setVisible(false);
            ComboBox_month2.setVisible(false);
            ComboBox_day2.setVisible(false);
            button_register.setBounds(470,500,220,40);
            button_remove.setVisible(false);
            button_display.setText("Display");
        }
        if(c.equals("Clear") ||c.equals("Change to Academic Course")||c.equals("Change to Non Academic Course") )
        {
            Field.setText("");
            field_coursename.setText("");
            field_duration.setText("");
            field_level.setText("");
            field_credit.setText("");
            field_numofassessments.setText("");
            field_courseid2.setText("");
            field_courseleader.setText("");
            field_lecturer.setText("");
            ComboBox_year.setSelectedIndex(0);
            ComboBox_month.setSelectedIndex(0);
            ComboBox_day.setSelectedIndex(0);
            ComboBox_year1.setSelectedIndex(0);
            ComboBox_month1.setSelectedIndex(0);
            ComboBox_day1.setSelectedIndex(0);
            ComboBox_year2.setSelectedIndex(0);
            ComboBox_month2.setSelectedIndex(0);
            ComboBox_day2.setSelectedIndex(0);

        }
        else if (c.equals("Add Academic Course"))
        {
            int pk = 0;
            //form validation
            if(getCourseID().equals("")||getlevel().equals("")||getCredit().equals("")||getCourseName().equals(""))
            {
                JOptionPane.showMessageDialog(frame,"please fill the empty fields","Alert",JOptionPane.ERROR_MESSAGE);
                pk = 1;
            }

            if(pk==0)
            {
                //exception handling
                try
                {
                    getduration();
                    try{
                        getNumofAssessments();
                    }
                    catch(NumberFormatException ex)
                    {
                        JOptionPane.showMessageDialog(frame,"Enter a number in the text field of no. of assessments","Alert",JOptionPane.ERROR_MESSAGE);
                        pk=1;
                    }
                }
                catch(NumberFormatException ex)
                {
                    JOptionPane.showMessageDialog(frame,"enter a number in the text field of duration","Alert",JOptionPane.ERROR_MESSAGE);
                    pk=1;

                }
            }
            if(pk==0)
            {
                for(Course a: course)
                    if(getCourseID().equals(a.getcourseID()))
                    {
                        JOptionPane.showMessageDialog(frame,"the course with CourseID:"+getCourseID()+"has already been added.","Alert",JOptionPane.ERROR_MESSAGE);
                        pk=1;
                    } 
            }
            if(pk == 0)
            {course.add(new AcademicCourse(getCourseID(),getCourseName(),getduration(),getlevel(),getCredit(),getNumofAssessments()));

                JOptionPane.showMessageDialog(frame,"the course with CourseID:"+getCourseID()+"has been added.","Alert",JOptionPane.INFORMATION_MESSAGE);
                pk=1;

            }
        }
        else if (c.equals("Add Non-academic course"))
        {
            int pk = 0;
            //form validation
            if(getCourseID().equals("")||getprerequisite().equals("")||getCourseName().equals(""))
            {
                JOptionPane.showMessageDialog(frame,"please fill the empty fields","Alert",JOptionPane.ERROR_MESSAGE);
                pk = 1;
            }

            if(pk==0)
            {
                //exception handling
                try
                {
                    getduration();

                }
                catch(NumberFormatException ex)
                {
                    JOptionPane.showMessageDialog(frame,"enter a number in the text field of duration","Alert",JOptionPane.ERROR_MESSAGE);
                    pk=1;

                }
            }
            if(pk==0)
            {
                for(Course a: course)
                    if(getCourseID().equals(a.getcourseID()))
                    {
                        JOptionPane.showMessageDialog(frame,"the course with CourseID:"+getCourseID()+"has already been added.","Alert",JOptionPane.ERROR_MESSAGE);
                        pk=1;
                    } 
            }
            if(pk == 0)
            {course.add(new NonAcademicCourse(getCourseID(),getCourseName(),getduration(),getprerequisite()));
                JOptionPane.showMessageDialog(frame," The course has been added with following details:\n"+
                    "CourseID:"+getCourseID()+"\n"+
                    "Course Name:"+getCourseName()+"\n"+
                    "Duration:"+getduration()+"\n"+
                    "Prerequisite:"+getprerequisite());}
        }

        else if (c.equals("Register academic course")){
            int pk=0;
            // if(getCourseID().equals("")||getCourseLeader().equals("")||getLecturerName().equals(""))

            for(Course a: course)
            {
                if (field_courseid2.getText().equals(a.getcourseID()) && a instanceof AcademicCourse)
                {
                    AcademicCourse ac = (AcademicCourse) a;
                    pk = 2;
                    if(ac.getisRegistered() == true)
                    {
                        JOptionPane.showMessageDialog(frame,"The course with CourseID: " + getcourseid2() + " has already been registered.","Alert",JOptionPane.ERROR_MESSAGE);
                    }
                    else if(ac.getisRegistered() == false)
                    {
                        ac.register(getCourseLeader(),getLecturerName(),getstartdate(),getcompletiondate(),getNumofAssessments(),getlevel(),getCredit());
                        JOptionPane.showMessageDialog(frame,"Academic course has been registered with following details:\n" +
                            "Course ID: " + getcourseid2() + "\n" + 
                            "Course Leader: " + getCourseLeader() + "\n" +
                            "Lecturer Name: " + getLecturerName() + "\n" +
                            "Start Date: " + getstartdate() + "\n" +
                            "Completion Date: " + getcompletiondate());
                    } 

                }
            }}
        else if (c.equals("register non academic"))
        {
            int pk =0;
            for(Course a: course)
            {
                if (field_courseid2.getText().equals(a.getcourseID()) && a instanceof NonAcademicCourse)
                {
                    NonAcademicCourse ac = (NonAcademicCourse) a;
                    pk = 2;
                    if(ac.getisRegistered() == true)
                    {
                        JOptionPane.showMessageDialog(frame,"The course with CourseID: " + getcourseid2() + " has already been registered.","Alert",JOptionPane.ERROR_MESSAGE);
                    }
                    else if(ac.getisRegistered() == false)
                    {
                        ac.register(getCourseLeader(),getLecturerName(),getstartdate(),getcompletiondate(),getexamdate());
                        JOptionPane.showMessageDialog(frame,"Non Academic course has been registered with following details:\n" +
                            "Course ID: " + getcourseid2() + "\n" + 
                            "Course Leader: " + getCourseLeader() + "\n" +
                            "Lecturer Name: " + getLecturerName() + "\n" +
                            "Start Date: " + getstartdate() + "\n" +
                            "Completion Date: " + getcompletiondate() + "\n" +
                            "Exam Date: " + getexamdate() );
                    } 

                }
            }

        }

        else if (c.equals("Display")){
            for(Course a: course)
            {
                if (a instanceof AcademicCourse)
                {
                    AcademicCourse ac = (AcademicCourse) a;
                    ac.display();
                }
            }        
        }

        else if (c.equals("Display ")){
            for(Course a: course)
            {
                if (a instanceof NonAcademicCourse)
                {
                    NonAcademicCourse ac = (NonAcademicCourse) a;
                    ac.display();
                }
            }        
        }
        else if (c.equals("Remove"))
        {
            int pk =0;
            for(Course a: course)
            {
                if (field_courseid2.getText().equals(a.getcourseID()) && a instanceof NonAcademicCourse)
                {
                    NonAcademicCourse ac = (NonAcademicCourse) a;
                    pk = 2;
                    if(ac.getisRemoved() == true)
                    {
                        JOptionPane.showMessageDialog(frame,"The course with CourseID: "+getcourseid2()+ " has already been removed.","Alert",JOptionPane.ERROR_MESSAGE);
                        break;
                    }
                    else if(ac.getisRemoved() == false)
                    {
                        ac.remove();
                        JOptionPane.showMessageDialog(frame,"Non-Academic course with CourseID: "+ getcourseid2()+" has been successfully removed.");
                        break;
                    }}

            }}

    }
    public static void main (String[] args)
    {
        new INGCollege().gui();
    }
}

