
/**
 * Write a description of class Non_academic_course here.
 *
 * @author (Dipesh raj sharma)
 * @version (a version number or a date)
 */
public class NonAcademicCourse extends Course
{
    //-----------Object Declaration----------
    private String InstructorName;
    private int Duration;
    private String StartDate;
    private String CompletionDate;
    private String ExamDate;
    private String PreRequisite;
    private boolean isRegistered;
    private boolean isRemoved;

    //-----------Constructor-----------------
    NonAcademicCourse(String CourseID, String CourseName, int Duration, String PreRequisite)
    {
        super(CourseID, CourseName, Duration);
        this.PreRequisite = PreRequisite;
        this.StartDate = "";
        this.CompletionDate = "";
        this.ExamDate = "";
        this.isRegistered = false;
        this.isRemoved = false;
    }
    // -----------Accessor Method-----------
    public String getInstructorName()
    {
        return this.InstructorName;
    }
    
    public int getDuration()
    {
        return this.Duration;
    }
    
    public String getStartDate()
    {
        return this.StartDate;
    }
    
    public String getCompletionDate()
    {
        return this.CompletionDate;
    }
    
    public String getExamDate()
    {
        return this.ExamDate;
    }
    
    public String getPreRequisite()
    {
        return this.PreRequisite;
    }
    
    public boolean getisRegistered()
    {
        return this.isRegistered;
    }
    
    public boolean getisRemoved()
    {
        return this.isRemoved;
    }
    //------------Mutator Method------------
    public void setInstructorName(String InstructorName)
    {
        if(isRegistered == false)
        {
            this.InstructorName = InstructorName;
        }
        
        else if(isRegistered == true)
        {
            System.out.println("Can't change Instructor Name as Non-Academic Course has already been registered.");
        } 
    }
    //------------Register Method----------- //
    public void register(String CourseLeader, String InstructorName, String StartDate, String CompletionDate, String ExamDate)
    {
        if(isRegistered == false)
        {
            setInstructorName(InstructorName);
            this.isRegistered = true;
            this.CompletionDate = CompletionDate;
            this.ExamDate=ExamDate;
            this.StartDate=StartDate;
        }
        
        else if(isRegistered == true)
        {
            System.out.println("The course has already been registered.");
            
        }
    }
    //------------Remove Method-------------
    public void remove()
    {
        if(isRemoved == true)
        {
            System.out.println("The course has already been removed.");
        }
        
        else if(isRemoved == false)
        {
            super.setcourseleader("");
            this.InstructorName = "";
            this.StartDate = "";
            this.CompletionDate = "";
            this.ExamDate = "";
            this.isRegistered = false;
            this.isRemoved = true;
        }
    }
    //------------Display Method-------------
    public void display()
    {
        super.display();
        if(isRegistered == true)
        {
            System.out.println("Instructor Name : " + this.InstructorName);
            System.out.println("Starting Date : " + this.StartDate);
            System.out.println("Completion Date : " + this.CompletionDate);
            System.out.println("Exam Date : " + this.ExamDate);
        }
    }
}
