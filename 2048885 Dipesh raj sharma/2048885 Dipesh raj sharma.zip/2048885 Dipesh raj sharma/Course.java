
/**
 * Write a description of class Course here.
 *
 * @author (Dipesh raj sharma)
 * @version (a version number or a date)
 */


   public class Course
{
    //----------Declaring Objects----------
    private String courseID;
    private String coursename;
    private String courseleader;
    private int duration;
    //----------Constructor----------
    Course(String CourseID, String CourseName, int Duration)
    {
        this.courseID = CourseID;
        this.coursename = CourseName;
        this.duration = Duration;
        this.courseleader = "";
    }
    //----------Accessor Method------
    public String getcourseID()
    {
        return this.courseID;
    }

    public String getcoursename()
    {
        return this.coursename;
    }

    public String getcourseleader()
    {
        return this.courseleader;
    }

    public int getduration()
    {
        return this.duration;
    }
    //----------Mutator Method-------
    public void setcourseleader(String CourseLeader)
    {
        this.courseleader = CourseLeader;
    }
    //----------Display Method-------
    public void display()
    {
        System.out.println("CourseID = " + courseID);
        System.out.println("Course Name = " + coursename);
        System.out.println("Course Duration = " + duration);

        if(courseleader != "")
        {
            System.out.println("Course Leader = " + courseleader);
        }
    }
}