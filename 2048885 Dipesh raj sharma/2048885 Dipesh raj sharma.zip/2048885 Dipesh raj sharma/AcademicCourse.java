
/**
 * Write a description of class Academic_course here.
 *
 * @author (Dipesh raj sharma)
 * @version (a version number or a date)
 */
   
 public class AcademicCourse extends Course
    {
        // ----------- Objects Declaration -------------------//
    private String LecturerName;
    private String Level;
    private String Credit;
    private String StartingDate;
    private String CompletionDate;
    private int NumberofAssessments;
    private boolean isRegistered;
    
    // -------------- Initializing -------------------------//
    AcademicCourse(String CourseID, String CourseName, int Duration, String Level, String Credit, int NumberofAssessments)
    {
        super(CourseID, CourseName, Duration);
        this.LecturerName = "";
        this.StartingDate = "";
        this.CompletionDate = "";
        this.isRegistered = false;
    }
    
    public String getLecturerName()
    {
        return this.LecturerName;
    }
    
    public String getLevel()
    {
        return this.Level;
    }
    
    public String getCredit()
    {
        return this.Credit;
    }
    
    public String getStartingDate()
    {
        return this.StartingDate;
    }
    // --------------Accessor Methods---------- //
    public String getCompletionDate()
    {
        return this.CompletionDate;
    }
    
    public int getNumberofAssessments()
    {
        return this.NumberofAssessments;
    }
    
    public boolean getisRegistered()
    {
        return this.isRegistered;
    }
    // --------------Mutator Methods---------- //
    public void setLecturerName(String Lecturer)
    {
        this.LecturerName = Lecturer;
    }
    
    public void setNumberofAssessments(int NumberofAssessments)
    {
        this.NumberofAssessments = NumberofAssessments;
    }
    //---------------Register Method----------//
    public void register(String CourseLeader, String LecturerName, String StartingDate, String CompletionDate,int NumberofAssessments,String Level,String Credit)
    {
        if(isRegistered == true)
        {
            System.out.println("The Academic Course is already registered.");
            System.out.println("Instructor Name = " + this.LecturerName);
            System.out.println("Starting Date = " + this.StartingDate);
            System.out.println("Completion Date = " + this.CompletionDate);
        }
        
        else if(isRegistered ==false)
        {
            super.setcourseleader(CourseLeader);
            this.LecturerName = LecturerName;
            this.StartingDate = StartingDate;
            this.CompletionDate = CompletionDate;
            this.isRegistered = true;
            this.Level = Level;
            this.Credit = Credit;
            setNumberofAssessments(NumberofAssessments);
            boolean CourseRemoved = false; 
        }
    }
    //-----------Display Method-------------------//
    public void display()
    {
        super.display();
        if(isRegistered == true)
        {
            System.out.println("Lecturer Name = " + this.LecturerName);
            System.out.println("Level = " + this.Level);
            System.out.println("Credit = " + this.Credit);
            System.out.println("Starting Date = " + this.StartingDate);
            System.out.println("Completion Date = " + this.CompletionDate);
            System.out.println("Number of Assessments = " + this.NumberofAssessments);
        }
    }
}
